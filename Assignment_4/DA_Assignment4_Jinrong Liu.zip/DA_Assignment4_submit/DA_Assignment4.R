install.packages("ggplot2")
library("ggplot2")
titanicFile <- read.csv("/Users/LJR/Desktop/train.csv", header=TRUE, sep=',')

# Whisker-plot
p1 <- ggplot(titanicFile, aes(factor(SibSp+Parch+1), Survived))
p1 + geom_boxplot() + ggtitle("Family Size as the Survival Factor")

# Histogram
p2 <- ggplot(titanicFile,aes(SibSp))
p2 + geom_histogram(binwidth=1) +ggtitle("Statistics based on siblings")

# Facet grid
p3 <- ggplot(data=titanicFile, aes(x=Pclass, fill=factor(Survived)))
p3 + geom_bar(position = 'fill') + facet_grid(~Sex)+ggtitle("Pclass and Sex as the Survival Factors")

# Violin plot
p4 <- ggplot(titanicFile,aes(factor(Pclass),Survived))
p4 + geom_violin() + ggtitle("Passenger class as survival factor")

# Heatmap
p5 <- ggplot(data = titanicFile, aes(x=Age, y=Pclass, fill=Survived))
p5 + geom_tile(aes(fill = Survived, width =3)) + ggtitle("age and passenger class as suvival factors")
