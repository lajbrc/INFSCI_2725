import sys
import pymongo
from pymongo import MongoClient
from sys import stdin

client = MongoClient()
db = client.test
ratings = db.ratings

for line in stdin:
    line = line.strip()
    userid, movieid, rating, timestamp = line.split('::')
    doc = {"UserID": int(userid), "MovieID": int(movieid), "Rating": float(rating), "Timestamp": timestamp}
    ratings.insert_one(doc)