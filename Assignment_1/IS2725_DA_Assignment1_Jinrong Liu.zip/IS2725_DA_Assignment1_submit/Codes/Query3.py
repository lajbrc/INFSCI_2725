import sys
import pymongo
from pymongo import MongoClient
client = MongoClient()
db = client.test
import re

mid = db.movies.find({"Title":{"$regex":"Space Odyssey"}}, {"MovieID":1, "_id":0})
tempmid = 0
for a in mid:
    tempmid = int(a['MovieID'])

tag = db.tags.find({'UserID':146, 'MovieID':tempmid},{"Tag":1,"_id":0})
for b in tag:
    print b
