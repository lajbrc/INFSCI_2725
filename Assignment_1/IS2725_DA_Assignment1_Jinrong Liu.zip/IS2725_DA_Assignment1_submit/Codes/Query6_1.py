import sys
import re
import pymongo
from pymongo import MongoClient
from bson.son import SON

client = MongoClient()
db = client['test']
movies = db['movies']

db.movies.aggregate([
	{"$match":{"Title":{"$regex":"Copycat"}}},
	{"$out":"CopycatInfo"}
])

collection = db.CopycatInfo

data = collection.find({"Genres":{"$regex":"Animation"}})

if(data is None):
	print("Movie CopyCat doesn't belong to Animation movies")
else:
	print("Movie CopyCat belongs to Animation movies")

