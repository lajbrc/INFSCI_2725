import sys
import pymongo
from pymongo import MongoClient
client = MongoClient()
db = client.test

cursor = db.ar4.find().sort([{"AvgRating", pymongo.DESCENDING}]).limit(10)
for doc in cursor:
    print doc