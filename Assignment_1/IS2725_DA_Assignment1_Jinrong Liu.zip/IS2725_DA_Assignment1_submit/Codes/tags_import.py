import sys
import pymongo
from pymongo import MongoClient
from sys import stdin

client = MongoClient()
db = client.test
tags = db.tags

for line in stdin:
    line = line.strip()
    userid, movieid, tag, timestamp = line.split('::')
    doc = {"UserID": int(userid), "MovieID": int(movieid), "Tag": tag, "Timestamp": timestamp}
    tags.insert_one(doc)