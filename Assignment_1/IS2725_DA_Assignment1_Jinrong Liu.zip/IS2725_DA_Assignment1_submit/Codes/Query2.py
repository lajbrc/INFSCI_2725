import sys
import re
import pymongo
from pymongo import MongoClient

client = MongoClient()
db = client['test']
collection = db['movies']

Action = collection.find({"Genres":{"$regex":"Action"}}).count()
Adventure = collection.find({"Genres":{"$regex":"Adventure"}}).count()
Animation = collection.find({"Genres":{"$regex":"Animation"}}).count()
Children = collection.find({"Genres":{"$regex":"Children"}}).count()
Comedy = collection.find({"Genres":{"$regex":"Comedy"}}).count()
Crime = collection.find({"Genres":{"$regex":"Crime"}}).count()
Documentary = collection.find({"Genres":{"$regex":"Documentary"}}).count()
Drama =collection.find({"Genres":{"$regex":"Drama"}}).count()
Fantasy = collection.find({"Genres":{"$regex":"Fantasy"}}).count()
Film_Noir = collection.find({"Genres":{"$regex":"Film-Noir"}}).count()
Horror = collection.find({"Genres":{"$regex":"Horror"}}).count()
Musical = collection.find({"Genres":{"$regex":"Musical"}}).count()
Mystery = collection.find({"Genres":{"$regex":"Mystery"}}).count()
Romance = collection.find({"Genres":{"$regex":"Romance"}}).count()
Sci_Fi = collection.find({"Genres":{"$regex":"Sci-Fi"}}).count()
Thriller = collection.find({"Genres":{"$regex":"Thriller"}}).count()
War = collection.find({"Genres":{"$regex":"War"}}).count()
Western = collection.find({"Genres":{"$regex":"Western"}}).count()

result = max(Action,Adventure,Animation,Children,Comedy,Crime,Documentary,Drama,Fantasy,Film_Noir,Horror,Musical,Mystery,Romance,Sci_Fi,Thriller,War,Western)

if(result==Action):
	print("Genere Action has the most movies!")
	print(Action)
elif(result==Adventure):
	print("Genere Adventure has the most movies!")
	print(Adventure)
elif(result==Animation):
	print("Genere Animation has the most movies!")
elif(result==Children):
	print("Genere Children has the most movies!")
elif(result==Comedy):
	print("Genere Comedy has the most movies!")
elif(result==Crime):
	print("Genere Crime has the most movies!")
elif(result==Documentary):
	print("Genere Documentary has the most movies!")
elif(result==Drama):
	print("Genere Drama has the most movies!")
	print(Drama)
elif(result==Film_Noir):
	print("Genere Film-Noir has the most movies!")
elif(result==Fantasy):
	print("Genere Fantasy has the most movies!")
elif(result==Horror):
	print("Genere Horror has the most movies!")
elif(result==Adventure):
	print("Genere Adventure has the most movies!")
elif(result==Musical):
	print("Genere Musical has the most movies!")
elif(result==Mystery):
	print("Genere Adventure has the most movies!")
elif(result==Romance):
	print("Genere Romance has the most movies!")
elif(result==Sci_Fi):
	print("Genere Sci-Fi has the most movies!")
elif(result==Thriller):
	print("Genere Thriller has the most movies!")
elif(result==War):
	print("Genere War has the most movies!")
elif(result==Western):
	print("Genere Western has the most movies!")
else:
	print("There might be some values equal to each other!")


