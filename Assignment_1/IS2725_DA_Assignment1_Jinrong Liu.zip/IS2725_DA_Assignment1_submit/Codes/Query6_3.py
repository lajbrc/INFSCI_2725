import sys
import re
import pymongo
from bson.son import SON
from pymongo import MongoClient

client = MongoClient()
db = client['test']
movies = db.movies
ar4 = db.ar4

action_movies = movies.find({"Genres":{"$regex":"Action"}},{"_id":0,"Title":0,"Genres":0})

action_list = list()
for m in action_movies:
	action_list.append(m['MovieID'])

ar6 = ar4.find().sort("AvgRating",-1)
rating_list = list()
for d in ar6:
	rating_list.append(d['_id'])

	
i =0
j=0
highest = 0
l1 = len(rating_list)
l2 = len(action_list)

while(i<l1):
		while(j<l2):
			if(action_list[j]==rating_list[i]):
				highest = action_list[j]
				break
			else:
				j = j+1
		i = i+1

result = movies.find({"MovieID":highest},{"_id":0,"MovieID":0,"Genres":0})
for r in result:
	print("The highest action movie is:")
	print(r)


