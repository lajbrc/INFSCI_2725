import pymongo
from pymongo import MongoClient
client = MongoClient()
db = client.test
import re
movie_title = re.compile(r'Copycat')
cursor = db.movies.find({'Title': movie_title})
for document in cursor:
    print document
    
