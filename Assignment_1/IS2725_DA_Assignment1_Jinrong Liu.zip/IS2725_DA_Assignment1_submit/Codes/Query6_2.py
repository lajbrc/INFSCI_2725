import sys
import re
import pymongo
from bson.son import SON
from pymongo import MongoClient
client = MongoClient()
db = client.test

sID = 0
silverID = db.movies.find({"Title":{"$regex":"Silver"}}, {"MovieID":1, "_id":0})
for a in silverID:
    sID = int(a['MovieID'])
    
lRating = db.ratings.find({"MovieID": sID}).sort([('Rating', pymongo.ASCENDING)]).limit(10)
for b in lRating:
    print b