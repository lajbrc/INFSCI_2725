import sys
import re
import pymongo
from bson.son import SON
from pymongo import MongoClient
client = MongoClient()
db = client.test

avgRating = db.ratings.aggregate([{"$group":{"_id":"$MovieID", "AvgRating":{"$avg": "$Rating"}}},{"$out": "ar4"}])

mid = list()
sortRating = db.ar4.find().sort([{"AvgRating", pymongo.DESCENDING}]).limit(5)
for a in sortRating:
    mid.append(a['_id'])
#print mid[0:5]

result = list()
for i in mid:
    mTitle = db.movies.find({"MovieID": i}, {"Title":1, "_id":0})
    for b in mTitle:
        result.append(b)
print result[0:5]
    
