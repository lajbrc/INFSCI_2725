INFSCI2725_DATA ANALYTICS_ASSIGNMENT1

Group Members: Jinrong Liu, Fengxi Liu

1. Import movie.dat, ratings.dat, and tags.dat into mongodb.
For example, run "python movie_import.py < movie.dat" in terminal (replace the filename with the corresponding path).

2. Questions:
1) What genre is the movie Copycat in?
--Crime|Drama|Horror|Mystery|Thriller
--Please see Query1.py

2) What genren has the most movies?
--Drama
—-Please see Query2.py

3) What tags did user 146 use to describe the movie "2001: A Space Odyssey"?
--Arthur C. Clarke
  artificial intelligence
  based on a book
--Please see Query3.py

4) What are the top 5 movies with the highest average rating?
--Satan’s Tango (Sátántangó) (1994)
  Sun Alley (Sonnenallee) (1999)
  Fighting Elegy (Kenka erejii) (1966)
  Shadows of Forgotten Ancestors (1964)
  Blue Light, The (Das Blaue Licht) (1932)
--Please see Query4.py

5) What is the highest average rating possible?
--The highest average rating possibly be 5.
--Please see Query5.py.
  Note: you have to run Query4.py before running Query5.py, because in Query5.py we have to use the collection "ar4" that we created in Query4.py.

6) Write 3 different queries of your choice to demonstrate that your data storage is working.
--a. Does "Toy Story" belongs to the genre of "Animation"?
     Yes, "Toy Story" belongs to the Animation genre.
     Please see Query6_1.py

--b. What is the lowest rating that the movie Silver get?
     The lowest rating that Silver get is 0.5.
     Please see Query6_2.py

--c. What Action movie has the highest average rating?
     Where A Good Man Goes (Joi gin a long) (1999)
     Please see Query6_3.py






